def play_mod():
    print('module works')

def number_of_tweets_per_day(df):
    # your code here
    return df
