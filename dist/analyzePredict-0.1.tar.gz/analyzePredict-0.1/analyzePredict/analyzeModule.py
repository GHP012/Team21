def play_mod():
    print('module works')
